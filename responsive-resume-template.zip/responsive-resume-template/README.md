# Responsive Resume Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/mariosmaselli/pen/popWjr](https://codepen.io/mariosmaselli/pen/popWjr).

Responsive resume template, you just need to fill out the content with your own. 